//
//  ViewController.swift
//  countDownTimer
//
//  Created by Anna Ovchinnikova on 11/11/18.
//  Copyright © 2018 Anna Ovchinnikova. All rights reserved.
//

import UIKit
import AVFoundation
class ViewController: UIViewController {
 
    var player = AVAudioPlayer()
    
    var countdownTimer:Timer!
    var totalTime = 0
    var isTimerRunning = false
    var savedTotalTime = 0
     var boolPressed = false
    
    var selectButton = false
    
    @IBOutlet weak var stopStartButton: UIButton!
    
    @IBOutlet weak var hTimer: UITextField!
    @IBOutlet weak var mTimer: UITextField!
    @IBOutlet weak var sTimer: UITextField!
    
    
    @IBAction func startButton(_ sender: UIButton) {
       /* if(boolPressed == true && selectButton==true){
            stopStartButton.isSelected = false
            boolPressed = false
            
            startTimer()
        }*/
        if(boolPressed == false && costyl >= 1){
            stopStartButton.isSelected = true
            boolPressed = true
            totalTime = Int(hTimer.text!)!*3600 + Int(mTimer.text!)!*60 + Int(sTimer.text!)!
            //savedTotalTime = totalTime //ОШИБКА
            startTimer()
            
        }
        else  if(boolPressed == false){
        stopStartButton.isSelected = true
        boolPressed = true
        totalTime = Int(hTimer.text!)!*3600 + Int(mTimer.text!)!*60 + Int(sTimer.text!)!
        savedTotalTime = totalTime
        startTimer()
           
        }else if (boolPressed == true ){
            
            boolPressed = false
            stopStartButton.isSelected = false
            endTimerExactlyStop()
            
            
        }
       
 
 }
    func endTimerExactlyStop(){
        countdownTimer.invalidate()
        isTimerRunning = false
        
    }
  
 
    
 
    @IBAction func invalidateButton(_ sender: UIButton) {
        
        endTimer()
        totalTime = savedTotalTime
        setValueToFields()
       
        
    }
    
   var costyl = 0
    
    func startTimer() {
        isTimerRunning = true
        countdownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTime), userInfo: nil, repeats: true)
        costyl += 1
    }
    
    
    @objc func updateTime() {
        
        //if totalTime != -1 {setValueToFields()}
        if totalTime != -1 {
            setValueToFields()
            totalTime -= 1
        } else {
            player.play()
            endTimer()
            
        }
    }
    
    func endTimer() {
        //sound()
        countdownTimer.invalidate()
        isTimerRunning = false
        
        if (boolSelectButton == true){
            totalTime = savedTotalTime
            startTimer()
        }else{
            stopStartButton.isSelected = false
        }
        
    
        
    }
    
    
    func timeToZero(){
        hTimer.text = "00"
        mTimer.text = "00"
        sTimer.text = "00"
    }
    
    func setValueToFields(){
        hTimer.text = String(format: "%02d", totalTime/3600)
        mTimer.text = String(format: "%02d", (totalTime%3600)/60)
        sTimer.text = String(format: "%02d", (totalTime%3600)%60)
    }

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       timeToZero()
        do{
            let audioPath = Bundle.main.path(forResource: "bell",ofType: "mp3")
            try player = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audioPath!)as URL)
        }
        catch{
            print("Problem with audio")
        }
        
    }

    
    
   /* @IBAction func buttonStopPressed(_ sender: UIButton) {
        if boolPressed == true{
        sender.isSelected = true
            boolPressed = false
        }
        else{
            sender.isSelected = false
            boolPressed = true
        }
        
    }*/
    
    var boolSelectButton = false
    
    
    @IBAction func selectButton(_ sender: UIButton) {
        if boolSelectButton == false {
            sender.isSelected = true
            boolSelectButton = true
            
        } else {
            sender.isSelected = false
            boolSelectButton = false
           
        }
    }
    
    /*func invalidatee(){
   // endTimer()
    totalTime = savedTotalTime
        
    setValueToFields()
    }*/
    
}

